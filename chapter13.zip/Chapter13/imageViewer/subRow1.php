<?php 
include ("header.php");
?>
<table width="753" height="186" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr> 
    <td height="15" width="250" colspan="2"><img src="Images/imageViewer.gif" width="250" height="15"></td>
    <td height="15" width="1"><img src="Images/shim.gif" width="1" height="15"></td>
    <td height="15" width="250" colspan="2"><img src="Images/blankTitle.gif" width="250" height="15"></td>
    <td height="15" width="1"><img src="Images/shim.gif" width="1" height="15"></td>
    <td height="15" width="250" colspan="2"><img src="Images/blankTitle.gif" width="250" height="15"></td>
    <td height="15" width="1"><img src="Images/shim.gif" width="1" height="15"></td>
  </tr>
  <tr> 
    <td width="234" align="left" valign="top" class="rfelement"><iframe name="inframe1" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" width="100%" height="148" src="imageViewer.php"></iframe>
      <p><img src="Images/shim.gif" width="10" height="4"></p>
	  <p><img src="Images/shim.gif" width="4" height="2">
        &copy;Mark's Photography</p></td>
    <td valign="top" ><img src="Images/right_side.gif" width="16" height="171"></td>
    <td width="1" height="171"></td>
    <td width="234" align="left" valign="top" class="rfelement"><iframe name="inframe2" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" width="100%" height="148" src="blank.php"></iframe></td>
    <td valign="top" ><img src="Images/right_side.gif" width="16" height="171"></td>
    <td width="1" height="171"></td>
    <td width="234" align="left" valign="top" class="rfelement"><iframe name="inframe3" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" width="100%" height="148" src="blank.php"></iframe></td>
    <td valign="top" ><img src="Images/right_side.gif" width="16" height="171"></td>
    <td width="1" height="171"></td>
  </tr>
</table>
</body>
</html>