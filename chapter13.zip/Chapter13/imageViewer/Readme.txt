We've had to make a very minor amendment to subRow1.php. If you open up the version of subRow1 you just downloaded, you'll notice that lines 18, 21, and 24 now read:

<td valign="top" ><img src="Images/right_side.gif" width="16" height="171"></td>

We've added the valign="top" so that the right_side.gif image is properly aligned within the cell.