<?php 
include ("header.php");
include ("row1.php");
/* add other rows here */
include ("footer.php");
?>

