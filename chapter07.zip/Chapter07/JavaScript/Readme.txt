These files relate to the following sections of Chapter 7:

jsbehavior.html		- 'Using a simple Javascript behavior' (pp 204 - 209)

jssnippets.html		- 'Creating and using Snippets' (pp 211 - 214) 
[N.B. You'll need to create the snippets locally when you're working through the exercise - this file is just for you to compare your final results.]

jsbehavior2.html 	- 'Setting up a JS file' (pp 215 - 217)

global.js 		- This is the JavaScript document that goes with jsbehavior2.html