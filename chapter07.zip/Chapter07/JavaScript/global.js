// JavaScript Document
function MM_displayStatusMsg(msgStr) { //v1.0
  status=msgStr;
  document.MM_returnValue = true;
}

function MM_popupMsg(msg) { //v1.0
  alert(msg);
}