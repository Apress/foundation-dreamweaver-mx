<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<form action="my_first_session.php" method="post"><input name="name" type="text">
  <input type="button" value="Submit">
</form>
</body>
</html>
