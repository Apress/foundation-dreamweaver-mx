<html>
<head>
<title>Survey</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<form name="guestbook" method="post" action="guestbook_post.php">
	<table width="400" border="0" cellspacing="1" cellpadding="2">
		<tr>
			<td><div align="right">Name:</div></td>
			<td><input type="text" name="name"></td>
		</tr>
		<tr>
			<td><div align="right">E-mail:</div></td>
			<td><input type="text" name="email"></td>
		</tr>
		<tr>
			<td><div align="right">Phone Number:</div></td>
			<td><input type="text" name="phone"></td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td><input type="submit" name="Submit" value="Submit"></td>
		</tr>
	</table>
</form>
</body>
</html>
