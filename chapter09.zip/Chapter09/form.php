<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<form method="GET" action="login.php">
<font size="3">Username:</font size>
<input type="text" name="name" size="10">

<input type="submit">

</form>

</body>
</html>
