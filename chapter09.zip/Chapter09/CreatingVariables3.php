<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?

$number = 3;
$number2 = 2;
$multiply = $number * $number2;
$divide = $number / $number2;
$subtract = $number - $number2;

echo "$number times $number2 equals $multiply <BR>";
echo "$number divided by $number2 equals $divide <BR>";
echo "$number minus $number2 equals $subtract <BR>";

?>
</body>
</html>
