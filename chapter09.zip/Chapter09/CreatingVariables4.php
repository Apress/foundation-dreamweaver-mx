<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?

$string1="Hello World!";
$string2="How are you?";
$string3="I'm doing well.";

echo "$string1 <BR> $string2 <BR> $string3";

?>
</body>
</html>
