<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<form method="GET" action="enter.php">

<font size="-1">Age: </font>
<input type="text" name="age" size="10"><BR>

<font size="-1">State: </font>
<input type="text" name="state" size="10">

<input type="submit">

</form>
</body>
</html>
