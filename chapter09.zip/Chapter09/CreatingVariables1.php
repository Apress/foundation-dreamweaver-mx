<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?

// Define Variables
$username=deviantART;
$password=dotcom;

// Sends text and variables to the browser.
echo "<b>Username:</b> $username<BR><b>Password:</b> $password";
?>
</body>
</html>
