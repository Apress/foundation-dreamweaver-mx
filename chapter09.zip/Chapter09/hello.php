<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?

include("greetings.php");
echo "Hello World!<BR>";
echo $greeting;

?>
</body>
</html>
