<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?

$greeting="What's going on?";
$greeting2="How are you today?";
$greeting3="Good morning.";
$greeting4="Good afternoon.";
$greeting5="Good evening.";

?>
</body>
</html>
