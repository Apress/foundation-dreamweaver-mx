<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?

$add1 = 1;
$add2 = 2;
$sum=$add1 + $add2;
echo $sum;

?>
</body>
</html>
