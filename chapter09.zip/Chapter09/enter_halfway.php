<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?
if ($age < 13) {
		if ($state == "Oklahoma")
				{
echo "We don't allow people under 13 from Oklahoma";
		}
		}
else 	{
		echo "You are able to enter.";
				}
?>
</body>
</html>
