<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<form action="form3.php" method="POST">
<select name="book[]" size="6" multiple>
		<option value="Crime and Punishment">Fyodor Dostoevsky</option>
		<option value="Wuthering Heights">Emily Bronte</option>
		<option value="Moby Dick">Herman Melville</option>
</select>
<br>
<input type="submit" name="submit" value="Submit">
</form>
</body>
</html>
